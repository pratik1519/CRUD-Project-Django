from  django.core import validators
from django import forms
from .models import Customer,Product,Order


class CustomerRegistration(forms.ModelForm):
	class Meta:
		model= Customer
		fields = ['id','firstname','lastname','contactno','pincode']

class ProductRegistration(forms.ModelForm):
	class Meta:
		model= Product
		fields = ['id','name','unitprice']

class OrderRegistration(forms.ModelForm):
	class Meta:
		model= Order
		fields = ['id','customerid','productid','unitprice','qty','totalprice','createdon']