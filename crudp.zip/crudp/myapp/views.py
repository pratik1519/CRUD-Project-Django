from django.shortcuts import render, HttpResponseRedirect
from .forms import CustomerRegistration,ProductRegistration,OrderRegistration
from .models import Customer, Product, Order

# Product part create update retrieve delete




def addorder(request):
	if request.method == 'POST':
		fm= ProductRegistration(request.POST)
		if  fm.is_valid():
			ig=fm.cleaned_data['id']
			nm=fm.cleaned_data['name']
			up=fm.cleaned_data['unitprice']
			reg= Product(id=ig,name=nm,unitprice=up)
			reg.save()


	else:
		fm= ProductRegistration()
	prod=Product.objects.all()

	return render(request, 'myapp/addorder.html',{'form':fm,'pro':prod})



def delete_data(request,id):
	if request.method == 'POST':
		pi = Product.objects.get(pk=id)
		pi.delete()
		return HttpResponseRedirect('/')

def update_data(request,id):
	if request.method == 'POST':
		pi = Product.objects.get(pk=id)
		fm = ProductRegistration(request.POST,instance=pi)
		if fm.is_valid():
		 fm.save()
	else:
		pi = Product.objects.get(pk=id)
		fm = ProductRegistration(instance=pi)
	return render(request,'myapp/editorder.html',{'form':fm})

#customer part Update delete retrieve create


