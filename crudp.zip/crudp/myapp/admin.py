from django.contrib import admin
from myapp.models import Customer, Product, Order


class CustomerAdmin(admin.ModelAdmin):
	list_display=('id','firstname','lastname','contactno','pincode')

class ProductAdmin(admin.ModelAdmin):
	list_display=('id','name','unitprice')

class OrderAdmin(admin.ModelAdmin):
	list_display=('id','customerid','productid','unitprice','qty','totalprice','createdon')

admin.site.register(Customer, CustomerAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Order, OrderAdmin)

