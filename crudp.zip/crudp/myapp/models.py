from django.db import models
from datetime import datetime 
# Create your models here.



class Customer(models.Model):
    id = models.IntegerField(primary_key=True,null=False)
    firstname = models.CharField(max_length = 25)
    lastname = models.CharField(max_length = 25)
    contactno= models.IntegerField(max_length = 15)
    pincode= models.IntegerField()


    def __str__(self):
        return self.firstname 


class Product(models.Model):
    id = models.IntegerField(primary_key=True,null=False)
    name = models.CharField(max_length = 50)
    unitprice = models.DecimalField(max_digits=6, decimal_places=2)
    
    def __str__(self):
        return self.name


class Order(models.Model):
    id = models.IntegerField(primary_key=True,null=False)
    customerid=models.ForeignKey(Customer, default=None, on_delete=models.CASCADE)
    productid=models.ForeignKey(Product, default=None, on_delete=models.CASCADE)
    unitprice = models.DecimalField(max_digits=6, decimal_places=2)
    qty=models.IntegerField()
    totalprice=models.DecimalField(max_digits=10, decimal_places=2)
    createdon = models.DateTimeField(default=datetime.now, blank=True)